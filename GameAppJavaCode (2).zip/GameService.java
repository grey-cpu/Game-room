import java.util.*;

public class GameService {
    private static GameService instance;

    private int nextGameId = 1;
    private int nextTeamId = 1;
    private int nextPlayerId = 1;

    private List<Game> games = new ArrayList<>();

    private GameService() {}

    public static GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    public Game addGame(String name) {
        if (getGame(name) != null) return null;
        Game game = new Game(nextGameId++, name);
        games.add(game);
        return game;
    }

    public Game getGame(String name) {
        for (Game g : games) {
            if (g.getName().equalsIgnoreCase(name)) return g;
        }
        return null;
    }

    public Team addTeam(Game game, String name) {
        for (Team t : game.getTeams()) {
            if (t.getName().equalsIgnoreCase(name)) return null;
        }
        Team team = new Team(nextTeamId++, name);
        game.addTeam(team);
        return team;
    }

    public Player addPlayer(Team team, String name) {
        for (Player p : team.getPlayers()) {
            if (p.getName().equalsIgnoreCase(name)) return null;
        }
        Player player = new Player(nextPlayerId++, name);
        team.addPlayer(player);
        return player;
    }
}