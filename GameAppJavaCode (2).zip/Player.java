public class Player extends Entity {
    public Player(int id, String name) {
        super(id, name);
    }
}