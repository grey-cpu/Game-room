public class ProgramDriver {
    public static void main(String[] args) {
        GameService service = GameService.getInstance();

        Game game1 = service.addGame("Galaxy Battle");
        if (game1 != null) System.out.println("Game created: " + game1);

        Team teamAlpha = service.addTeam(game1, "Team Alpha");
        if (teamAlpha != null) System.out.println("Team created: " + teamAlpha);

        Player p1 = service.addPlayer(teamAlpha, "Frances");
        if (p1 != null) System.out.println("Player added: " + p1);

        Game duplicate = service.addGame("Galaxy Battle");
        if (duplicate == null) System.out.println("Duplicate game name blocked.");
    }
}